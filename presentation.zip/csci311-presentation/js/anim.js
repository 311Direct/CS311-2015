$(document).keypress(function(e) {
	if (e.which == 97) {	// 97 = 'a' key
		$('body').anim();	
	}
});

$.fn.anim = function() {
	// Reveal all
	$('.blindfold').css('opacity', 0);
	setTimeout(function() {
		$('.blindfold').remove();
	}, 1000);

	// Slide "mountains" up
	$('.mountains').css('bottom', 0);
	
	// Flip team member details
	$('.wodry').wodry({
		animation: 'rotateX',
		animationDuration: 2000,
		delay: 3500
	});	
	
	// Slide "Direct." left
	$('.title-letter-0').css('margin-left', '0');
	
	// Slide the mask over "Direct." to the right, slowly revealing "Direct." letter-by-letter
	var screenWidth = $(window).width() + 'px';
	$('.mask').css('left', screenWidth);
	
	// Underline
	setTimeout(function() {	
		$('.underline').css('width', screenWidth);
	}, 1800);
	
	// "Your lead in project management"
	setTimeout(function() {
		$('h2').css('opacity', '1');
	}, 3000);
	// Ensure readability for "Your lead in project management"
	setTimeout(function() {
		$('h2').css({
			'color': 'rgb(240, 240, 240)',
			'text-shadow': '1px 1px 2px black'
		});
	}, 7500);
	
	// Show "reveal" button
	setTimeout(function() {
		$('html, body').css('cursor', 'default');
		$('.reveal').css('opacity', 1);
	}, 20000);
};